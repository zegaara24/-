# تطبيق ألا بذكر الله تطمئن القلوب

هذا المشروع يحول ملف الموقع `index.html` إلى تطبيق Android باستخدام WebView.

- الحد الأدنى: Android 5.0 (API 21)
- الهدف: Android 14 وما بعده
- JavaScript وLocalStorage مفعّلان
- إذن الموقع مضاف لدعم صفحة القبلة
- يوجد GitHub Actions لبناء APK تلقائيًا

## بناء APK
يمكن فتح المشروع في Android Studio أو استخدام GitHub Actions:
Actions → Build APK → Run workflow.
بعد انتهاء البناء افتح Artifacts ونزّل `AlaBzikr-debug-apk`.
